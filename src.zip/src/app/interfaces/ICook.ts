export interface ICook {
  id ?: number,
  name ?: string,
  description ?: string,
  imageURL ?: string,
  rating ?: number
}
